# HelloControllerApi

All URIs are relative to *http://localhost:8082/hello*

Method | HTTP request | Description
------------- | ------------- | -------------
[**helloUsingGET**](HelloControllerApi.md#helloUsingGET) | **GET** /hello | 对某人说 hello


<a name="helloUsingGET"></a>
# **helloUsingGET**
> String helloUsingGET(name)

对某人说 hello

### Example
```java
// Import classes:
//import com.fang2chen.test.swagger.codegen.hello.client.ApiException;
//import com.fang2chen.test.swagger.codegen.hello.client.client.HelloControllerApi;


HelloControllerApi apiInstance = new HelloControllerApi();
String name = "name_example"; // String | name
try {
    String result = apiInstance.helloUsingGET(name);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling HelloControllerApi#helloUsingGET");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **name** | **String**| name |

### Return type

**String**

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: */*


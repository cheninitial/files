package com.fang2chen.test.swagger.codegen.hello.client.auth;

public enum OAuthFlow {
    accessCode, implicit, password, application
}